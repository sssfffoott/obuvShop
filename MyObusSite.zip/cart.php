<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/database.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    $_SESSION['redirect_to'] = 'cart.php';
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Обработка действий с корзиной
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action == 'update') {
        foreach ($_POST['quantity'] as $item_id => $quantity) {
            $quantity = intval($quantity);
            if ($quantity > 0) {
                updateCartQuantity($user_id, $item_id, $quantity);
            } else {
                removeFromCart($user_id, $item_id);
            }
        }
        $message = "Корзина обновлена";
    } elseif ($action == 'remove') {
        $item_id = intval($_POST['item_id'] ?? 0);
        removeFromCart($user_id, $item_id);
        $message = "Товар удален из корзины";
    } elseif ($action == 'clear') {
        clearCart($user_id);
        $message = "Корзина очищена";
    }
}

$cart_items = getCartItems($user_id);
$cart_total = getCartTotal($user_id);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Корзина</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .cart-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background: white;
        }
        
        .cart-table th {
            background: #2c3e50;
            color: white;
            padding: 15px;
            text-align: left;
        }
        
        .cart-table td {
            padding: 15px;
            border-bottom: 1px solid #eee;
        }
        
        .quantity-input {
            width: 60px;
            padding: 5px;
            text-align: center;
        }
        
        .cart-total {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
            text-align: right;
        }
        
        .empty-cart {
            text-align: center;
            padding: 50px;
            background: white;
            border-radius: 8px;
        }
        
        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
            border: 1px solid #c3e6cb;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container">
        <h1>Корзина покупок</h1>
        
        <?php if (isset($message)): ?>
            <div class="success-message"><?= $message ?></div>
        <?php endif; ?>
        
        <?php if (empty($cart_items)): ?>
            <div class="empty-cart">
                <h2>Ваша корзина пуста</h2>
                <p>Добавьте товары из каталога</p>
                <a href="catalog.php" class="btn">Перейти в каталог</a>
            </div>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="action" value="update">
                
                <table class="cart-table">
                    <thead>
                        <tr>
                            <th>Товар</th>
                            <th>Цена</th>
                            <th>Размер</th>
                            <th>Количество</th>
                            <th>Итого</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cart_items as $item): ?>
                        <tr>
                            <td>
                                <div style="display: flex; align-items: center; gap: 15px;">
                                    <?php if ($item['image_url']): ?>
                                        <img src="assets/images/<?= $item['image_url'] ?>" 
                                             alt="<?= htmlspecialchars($item['name']) ?>" 
                                             style="width: 80px; height: 80px; object-fit: cover;">
                                    <?php else: ?>
                                        <img src="assets/images/default.jpg" 
                                             alt="<?= htmlspecialchars($item['name']) ?>" 
                                             style="width: 80px; height: 80px; object-fit: cover;">
                                    <?php endif; ?>
                                    <div>
                                        <h4><?= htmlspecialchars($item['name']) ?></h4>
                                        <p style="color: #7f8c8d;"><?= $item['brand'] ?></p>
                                    </div>
                                </div>
                            </td>
                            <td><?= formatPrice($item['price']) ?></td>
                            <td><?= $item['size'] ?></td>
                            <td>
                                <input type="number" 
                                       name="quantity[<?= $item['cart_item_id'] ?>]" 
                                       value="<?= $item['quantity'] ?>" 
                                       min="1" 
                                       class="quantity-input">
                            </td>
                            <td><?= formatPrice($item['price'] * $item['quantity']) ?></td>
                            <td>
                                <button type="submit" 
                                        formaction="cart.php" 
                                        formmethod="POST"
                                        name="action" 
                                        value="remove"
                                        class="btn" 
                                        style="background: #e74c3c; padding: 5px 10px;">
                                    Удалить
                                </button>
                                <input type="hidden" name="item_id" value="<?= $item['cart_item_id'] ?>">
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <div style="display: flex; justify-content: space-between; margin-top: 20px;">
                    <button type="submit" class="btn">Обновить корзину</button>
                    
                    <form method="POST" style="display: inline;">
                        <input type="hidden" name="action" value="clear">
                        <button type="submit" class="btn" style="background: #95a5a6;">
                            Очистить корзину
                        </button>
                    </form>
                </div>
            </form>
            
            <div class="cart-total">
                <h3>Итого: <?= formatPrice($cart_total) ?></h3>
                <a href="checkout.php" class="btn" style="padding: 15px 30px; font-size: 1.2rem;">
                    Оформить заказ
                </a>
            </div>
        <?php endif; ?>
    </div>
    
    <div style="background: #2c3e50; color: white; padding: 2rem; margin-top: 3rem;">
        <div class="container">
            <p>&copy; 2024 Магазин обуви. Все права защищены.</p>
        </div>
    </div>
</body>
</html>