<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/database.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$db = getDB();

// Получение данных пользователя
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user) {
    header("Location: login.php");
    exit;
}

// Обновление профиля
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    
    if (empty($name)) {
        $message = 'Имя обязательно для заполнения';
    } else {
        $stmt = $db->prepare("UPDATE users SET name = ?, phone = ? WHERE id = ?");
        $stmt->bind_param("ssi", $name, $phone, $user_id);
        
        if ($stmt->execute()) {
            $_SESSION['user_name'] = $name;
            $message = 'Профиль успешно обновлен';
            $user['name'] = $name;
            $user['phone'] = $phone;
        } else {
            $message = 'Ошибка при обновлении профиля';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Мой профиль</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .form-container {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #333;
        }
        
        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="tel"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        
        .form-group input:disabled {
            background: #f5f5f5;
            cursor: not-allowed;
        }
        
        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
            border: 1px solid #c3e6cb;
        }
        
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
            border: 1px solid #f5c6cb;
        }
        
        .info-box {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .info-box p {
            margin: 10px 0;
            padding: 8px 0;
            border-bottom: 1px solid #eee;
        }
        
        .info-box strong {
            color: #333;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container">
        <h1>Мой профиль</h1>
        
        <?php if ($message): ?>
            <div class="<?= strpos($message, 'успешно') !== false ? 'success-message' : 'error-message' ?>">
                <?= $message ?>
            </div>
        <?php endif; ?>
        
        <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 40px; margin-top: 2rem;">
            <div>
                <div class="info-box">
                    <h3>Личная информация</h3>
                    <p><strong>Имя:</strong> <?= htmlspecialchars($user['name']) ?></p>
                    <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
                    <p><strong>Телефон:</strong> <?= htmlspecialchars($user['phone'] ?? 'не указан') ?></p>
                    <p><strong>Роль:</strong> <?= htmlspecialchars($user['role']) ?></p>
                    <p><strong>Дата регистрации:</strong> <?= date('d.m.Y', strtotime($user['created_at'])) ?></p>
                </div>
                
                <div style="margin-top: 20px;">
                    <h3>Быстрые ссылки</h3>
                    <div style="display: flex; flex-direction: column; gap: 10px; margin-top: 1rem;">
                        <a href="orders.php" class="btn">Мои заказы</a>
                        <a href="cart.php" class="btn">Корзина</a>
                    </div>
                </div>
            </div>
            
            <div>
                <div class="form-container">
                    <h3>Редактировать профиль</h3>
                    <form method="POST">
                        <div class="form-group">
                            <label>Имя *</label>
                            <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label>Телефон</label>
                            <input type="tel" name="phone" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" placeholder="+7 (999) 123-45-67">
                        </div>
                        
                        <div class="form-group">
                            <label>Email (нельзя изменить)</label>
                            <input type="email" value="<?= htmlspecialchars($user['email']) ?>" disabled>
                        </div>
                        
                        <button type="submit" class="btn">Сохранить изменения</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <div style="background: #2c3e50; color: white; padding: 2rem; margin-top: 3rem;">
        <div class="container">
            <p>&copy; 2024 Магазин обуви. Все права защищены.</p>
        </div>
    </div>
</body>
</html>