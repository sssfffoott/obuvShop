<?php
// Начинаем сессию
session_start();

// Подключаем конфигурацию
require_once 'includes/config.php';
require_once 'includes/database.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

// Получаем подключение к БД
$db = getDB();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Магазин обуви - Главная</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="header">
        <div class="container nav">
            <a href="index.php" class="logo">Обувной магазин</a>
            <div class="nav-links">
                <a href="index.php">Главная</a>
                <a href="catalog.php">Каталог</a>
                <a href="cart.php">Корзина</a>
                <?php if (isset($_SESSION['user_id'])) { ?>
                    <a href="profile.php">Профиль</a>
                    <a href="?logout=1">Выйти</a>
                <?php } else { ?>
                    <a href="login.php">Войти</a>
                    <a href="register.php">Регистрация</a>
                <?php } ?>
            </div>
        </div>
    </div>

    <div class="hero">
        <div class="container">
            <h2>Лучшая обувь для вас</h2>
            <p>Большой выбор обуви для всей семьи</p>
            <a href="catalog.php" class="btn">Смотреть каталог</a>
        </div>
    </div>

    <div class="container">
        <h2 style="margin-top: 2rem;">Популярные товары</h2>
        <div class="products-grid">
            <?php
            // Проверяем есть ли таблица products
            $check_table = $db->query("SHOW TABLES LIKE 'products'");
            
            if ($check_table->num_rows > 0) {
                // Получаем товары
                $sql = "SELECT * FROM products WHERE status = 'active' ORDER BY created_at DESC LIMIT 4";
                $result = $db->query($sql);
                
                if ($result && $result->num_rows > 0) {
                    while ($product = $result->fetch_assoc()) {
                        echo '<div class="product-card">';
                        echo '<img src="assets/images/default.jpg" alt="' . htmlspecialchars($product['name']) . '" class="product-image">';
                        echo '<div class="product-info">';
                        echo '<h3>' . htmlspecialchars($product['name']) . '</h3>';
                        echo '<p class="product-price">' . number_format($product['price'], 0, ',', ' ') . ' ₽</p>';
                        echo '<p>' . htmlspecialchars($product['brand']) . '</p>';
                        echo '<a href="product.php?id=' . $product['id'] . '" class="btn">Подробнее</a>';
                        echo '</div></div>';
                    }
                } else {
                    echo '<p>Товары пока не добавлены в базу данных.</p>';
                }
            } else {
                echo '<p>База данных не настроена. Пожалуйста, создайте таблицы в phpMyAdmin.</p>';
            }
            ?>
        </div>
    </div>

    <div class="footer">
        <div class="container">
            <p>&copy; 2024 Магазин обуви. Все права защищены.</p>
        </div>
    </div>

    <?php 
    if (isset($_GET['logout'])) {
        session_destroy();
        header("Location: index.php");
        exit;
    }
    ?>
</body>
</html>