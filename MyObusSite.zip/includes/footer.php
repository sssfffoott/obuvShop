    <div class="footer">
        <div class="container footer-content">
            <div class="footer-section">
                <h3>Магазин обуви</h3>
                <p>Лучшая обувь для всей семьи. Большой выбор, качественные материалы, доступные цены.</p>
            </div>
            
            <div class="footer-section">
                <h3>Контакты</h3>
                <p>Телефон: +7 (999) 123-45-67</p>
                <p>Email: info@shoestore.ru</p>
                <p>Адрес: г. Москва, ул. Примерная, д. 123</p>
            </div>
            
            <div class="footer-section">
                <h3>Полезные ссылки</h3>
                <p><a href="../catalog.php" style="color: white;">Каталог товаров</a></p>
                <p><a href="#" style="color: white;">О компании</a></p>
                <p><a href="#" style="color: white;">Доставка и оплата</a></p>
            </div>
        </div>
        
        <div class="container" style="margin-top: 2rem; padding-top: 1rem; border-top: 1px solid rgba(255,255,255,0.1);">
            <p>&copy; 2024 Магазин обуви. Все права защищены.</p>
        </div>
    </div>
</body>
</html>