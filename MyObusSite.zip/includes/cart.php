<?php
require_once 'auth.php';

class Cart {
    // Получение корзины пользователя из БД
    public static function getUserCart($user_id) {
        $db = getDB();
        $stmt = $db->prepare("
            SELECT ci.*, p.name, p.price, ps.size 
            FROM cart_items ci
            JOIN carts c ON ci.cart_id = c.id
            JOIN products p ON ci.product_id = p.id
            JOIN product_sizes ps ON ci.size_id = ps.id
            WHERE c.user_id = ?
        ");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    // Слияние локальной и БД корзины
    public static function mergeCarts($user_id, $localCart) {
        if (empty($localCart)) return;
        
        // Получаем корзину пользователя из БД
        $dbCart = self::getUserCart($user_id);
        
        // Для каждого товара в локальной корзине
        foreach ($localCart as $localItem) {
            $found = false;
            
            // Проверяем, есть ли такой товар в БД корзине
            foreach ($dbCart as $dbItem) {
                if ($dbItem['product_id'] == $localItem['product_id'] && 
                    $dbItem['size_id'] == $localItem['size_id']) {
                    // Суммируем количество
                    self::updateQuantity($dbItem['id'], $dbItem['quantity'] + $localItem['quantity']);
                    $found = true;
                    break;
                }
            }
            
            // Если не нашли, добавляем новый
            if (!$found) {
                self::addToDBCart($user_id, $localItem['product_id'], $localItem['size_id'], $localItem['quantity']);
            }
        }
        
        // Очищаем локальную корзину
        echo "<script>localStorage.removeItem('cart');</script>";
    }
    
    private static function addToDBCart($user_id, $product_id, $size_id, $quantity) {
        $db = getDB();
        
        // Получаем или создаем корзину
        $stmt = $db->prepare("SELECT id FROM carts WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $cart = $stmt->get_result()->fetch_assoc();
        
        if (!$cart) {
            $stmt = $db->prepare("INSERT INTO carts (user_id) VALUES (?)");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $cart_id = $db->insert_id;
        } else {
            $cart_id = $cart['id'];
        }
        
        // Добавляем товар
        $stmt = $db->prepare("INSERT INTO cart_items (cart_id, product_id, size_id, quantity) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiii", $cart_id, $product_id, $size_id, $quantity);
        $stmt->execute();
    }
    
    private static function updateQuantity($item_id, $quantity) {
        $db = getDB();
        $stmt = $db->prepare("UPDATE cart_items SET quantity = ? WHERE id = ?");
        $stmt->bind_param("ii", $quantity, $item_id);
        $stmt->execute();
    }
}
?>