<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/database.php';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Каталог обуви</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="header">
        <div class="container nav">
            <a href="index.php" class="logo">Обувной магазин</a>
            <div class="nav-links">
                <a href="index.php">Главная</a>
                <a href="catalog.php">Каталог</a>
                <a href="cart.php">Корзина</a>
                <?php if (isset($_SESSION['user_id'])) { ?>
                    <a href="profile.php">Профиль</a>
                    <a href="index.php?logout=1">Выйти</a>
                <?php } else { ?>
                    <a href="login.php">Войти</a>
                    <a href="register.php">Регистрация</a>
                <?php } ?>
            </div>
        </div>
    </div>
    
    <div class="container">
        <h1 style="margin-top: 2rem;">Каталог обуви</h1>
        
        <div class="filters">
            <form method="GET">
                <input type="text" name="search" placeholder="Поиск по названию..." 
                       value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                <button type="submit" class="btn">Поиск</button>
            </form>
        </div>
        
        <div class="products-grid">
            <?php
            $db = getDB();
            
            // Проверяем есть ли таблица products
            $check_table = $db->query("SHOW TABLES LIKE 'products'");
            
            if ($check_table->num_rows > 0) {
                $sql = "SELECT * FROM products WHERE status = 'active'";
                
                if (!empty($_GET['search'])) {
                    $search = $db->real_escape_string($_GET['search']);
                    $sql .= " AND (name LIKE '%$search%' OR description LIKE '%$search%')";
                }
                
                $sql .= " ORDER BY created_at DESC";
                $result = $db->query($sql);
                
                if ($result && $result->num_rows > 0) {
                    while ($product = $result->fetch_assoc()) {
                        echo '<div class="product-card">';
                        echo '<img src="assets/images/default.jpg" alt="' . htmlspecialchars($product['name']) . '" class="product-image">';
                        echo '<div class="product-info">';
                        echo '<h3>' . htmlspecialchars($product['name']) . '</h3>';
                        echo '<p class="product-price">' . number_format($product['price'], 0, ',', ' ') . ' ₽</p>';
                        echo '<p><strong>Бренд:</strong> ' . htmlspecialchars($product['brand']) . '</p>';
                        echo '<p><strong>Категория:</strong> ' . htmlspecialchars($product['category']) . '</p>';
                        echo '<a href="product.php?id=' . $product['id'] . '" class="btn">Подробнее</a>';
                        echo '</div></div>';
                    }
                } else {
                    echo '<p>Товары не найдены</p>';
                }
            } else {
                echo '<p>База данных не настроена.</p>';
            }
            ?>
        </div>
    </div>
    
    <div class="footer">
        <div class="container">
            <p>&copy; 2024 Магазин обуви. Все права защищены.</p>
        </div>
    </div>
</body>
</html>